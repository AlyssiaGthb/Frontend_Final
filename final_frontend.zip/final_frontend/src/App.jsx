import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import AuthPage from './pages/AuthPage';
import SubscriptionPage from './pages/SubscriptionPage';
import CandidateDashboard from './pages/CandidateDashboard';
import RecruiterDashboard from './pages/RecruiterDashboard';
import Chatbot from './pages/Chatbot';
import Navbar from './pages/Navbar';

const App = () => {
  const isAuthenticated = localStorage.getItem("access_token"); // Vérifier si l'utilisateur est connecté

  return (
    <Router>
      <div>
        <Navbar />
        <Routes>
          <Route path="/" element={<Navigate to={isAuthenticated ? "/dashboard" : "/auth"} />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route
            path="/dashboard"
            element={isAuthenticated ? <CandidateDashboard /> : <Navigate to="/auth" />}
          />
          <Route
            path="/recruiter"
            element={isAuthenticated ? <RecruiterDashboard /> : <Navigate to="/auth" />}
          />
          <Route path="/plan" element={<SubscriptionPage />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
       
        <Chatbot />
      </div>
    </Router>
  );
};

export default App;
