import React, { useState } from "react";
import axios from "axios";
import "./Chatbot.css"; 

const Chatbot = () => {
  const [visible, setVisible] = useState(false); // Contrôle de la visibilité
  const [messages, setMessages] = useState([]); // Historique des messages
  const [input, setInput] = useState(""); // Contenu de l'entrée utilisateur
  const [loading, setLoading] = useState(false); // Indicateur de chargement

  const toggleVisibility = () => {
    setVisible(!visible);
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { role: "user", content: input };
    setMessages([...messages, userMessage]); // Ajouter le message utilisateur
    setInput(""); 
    setLoading(true);

    try {
      const response = await axios.post("http://127.0.0.1:8005/chatbot", {
        question: input,
      });

      const botMessage = { role: "bot", content: response.data.response };
      setMessages((prev) => [...prev, botMessage]); // Ajouter le message du bot
    } catch (error) {
      console.error("Erreur lors de l'envoi de la requête :", error);
      const errorMessage = { role: "bot", content: "Une erreur est survenue. Veuillez réessayer." };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="chatbot-floating">
      <button className="chatbot-toggle" onClick={toggleVisibility}>
        {visible ? "Masquer" : "Chatbot"}
      </button>
      {visible && (
        <div className="chatbot-container">
          <div className="chatbot-messages">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`chatbot-message ${msg.role === "user" ? "user" : "bot"}`}
              >
                <strong>{msg.role === "user" ? "Vous" : "Cassandra"}:</strong> {msg.content}
              </div>
            ))}
            {loading && (
              <div className="chatbot-message bot">
                <strong>Cassandra:</strong> Chatbot is thinking...
              </div>
            )}
          </div>
          <div className="chatbot-input-container">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="chatbot-input"
              placeholder="Tapez votre message..."
              disabled={loading} 
            />
            <button
              onClick={sendMessage}
              className="chatbot-send-button"
              disabled={loading} 
            >
              Envoyer
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
