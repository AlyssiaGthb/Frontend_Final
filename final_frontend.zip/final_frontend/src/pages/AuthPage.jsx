import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom"; // Importer useNavigate
import axios from "axios";
import "./AuthPage.css";

const AuthPage = () => {
  const [step, setStep] = useState(1); // Étape actuelle : 1 pour inscription, 2 pour sélection du rôle, 3 pour message de succès
  const [formData, setFormData] = useState({ email: "", password: "", role: "" });
  const [errorMessage, setErrorMessage] = useState(null);
  const [successMessage, setSuccessMessage] = useState(""); // Message de succès
  const [isLoading, setIsLoading] = useState(false); // Ajout d'un état pour le chargement

  const navigate = useNavigate(); // Déclaration de useNavigate pour la redirection

  // Vérification du rôle utilisateur au montage
  useEffect(() => {
    const token = localStorage.getItem("access_token");
    const userRole = localStorage.getItem("user_role");

    if (token && userRole) {
      if (userRole === "candidate") {
        navigate("/dashboard");
      } else if (userRole === "recruiter") {
        navigate("/recruiter");
      }
    }
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage(null); // Réinitialiser les erreurs
    setIsLoading(true); // Activer le chargement

    try {
      const response = await axios.post("http://127.0.0.1:8000/login", {
        email: formData.email,
        password: formData.password,
      });

      const token = response.data.access_token;
      const userRole = response.data.role; // Récupérer le rôle depuis l'API

      if (!token || !userRole) {
        throw new Error("Le token ou le rôle n'a pas été reçu.");
      }

      console.log("Token reçu :", token);
      console.log("Rôle reçu :", userRole);

      localStorage.setItem("access_token", token);
      localStorage.setItem("user_role", userRole);

      // Redirection selon le rôle
      if (userRole === "candidate") {
        navigate("/dashboard");
      } else if (userRole === "recruiter") {
        navigate("/recruiter");
      } else {
        throw new Error("Rôle utilisateur inconnu.");
      }
    } catch (error) {
      console.error("Erreur de connexion:", error);
      setErrorMessage(
        error.response?.data?.detail || "Connexion échouée. Vérifiez vos informations."
      );
    } finally {
      setIsLoading(false); // Désactiver le chargement
    }
  };

  const handleRoleSelection = (role) => {
    setFormData({ ...formData, role });
    setErrorMessage(null); // Supprimer les messages d'erreur si un rôle est sélectionné
  };

  const handleSignupSubmit = async () => {
    setErrorMessage(null); // Réinitialiser les erreurs
    setIsLoading(true); // Activer le chargement

    try {
      const response = await axios.post("http://127.0.0.1:8000/signup", formData);
      console.log("Inscription réussie:", response.data);

      setSuccessMessage("Successfully signed up! Redirecting to subscription...");
      setStep(3); // Afficher le message de succès avant redirection
      setTimeout(() => navigate("/plan"), 2000); // Rediriger après 2 secondes
    } catch (error) {
      console.error("Erreur lors de l'inscription:", error);
      setErrorMessage(
        error.response?.data?.detail || "Une erreur est survenue lors de l'inscription."
      );
    } finally {
      setIsLoading(false); // Désactiver le chargement
    }
  };

  const goToLogin = () => {
    setStep(4); // Passer à la page de connexion
  };

  return (
    <div className="auth-page">
      <div className="auth-frame">
        <div className="auth-content">
          {step === 1 && (
            <div className="auth-form fade-in">
              <h2>Sign Up</h2>
              {errorMessage && <p className="error-message">{errorMessage}</p>}
              <form onSubmit={(e) => e.preventDefault()}>
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
                <input
                  type="password"
                  name="password"
                  placeholder="Password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
                <button
                  type="button"
                  className="submit-btn"
                  onClick={() => setStep(2)}
                >
                  Start
                </button>
              </form>
              <div className="toggle-signup">
                Already have an account? <span onClick={goToLogin}>Log in</span>
              </div>
            </div>
          )}
          {step === 2 && (
            <div className="role-selection fade-in">
              <h2>Select Your Role</h2>
              {errorMessage && <p className="error-message">{errorMessage}</p>}
              <div className="role-buttons">
                <button
                  className={`role-btn ${formData.role === "candidate" ? "selected" : ""}`}
                  onClick={() => handleRoleSelection("candidate")}
                >
                  Candidate
                </button>
                <button
                  className={`role-btn ${formData.role === "recruiter" ? "selected" : ""}`}
                  onClick={() => handleRoleSelection("recruiter")}
                >
                  Recruiter
                </button>
              </div>
              <button
                className="confirm-btn"
                onClick={handleSignupSubmit}
                disabled={!formData.role || isLoading} // Désactiver si aucun rôle n'est sélectionné
              >
                {isLoading ? "Loading..." : "Confirm"}
              </button>
            </div>
          )}
          {step === 3 && (
            <div className="success-message fade-in">
              <h2>{successMessage}</h2>
            </div>
          )}
          {step === 4 && (
            <div className="auth-form fade-in">
              <h2>Log In</h2>
              {errorMessage && <p className="error-message">{errorMessage}</p>}
              <form onSubmit={handleLoginSubmit}>
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
                <input
                  type="password"
                  name="password"
                  placeholder="Password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
                <button type="submit" className="submit-btn" disabled={isLoading}>
                  {isLoading ? "Loading..." : "Log In"}
                </button>
              </form>
            </div>
          )}
        </div>
        <div className="auth-image">
          <div className="container">
            <h1 className="slogan">
              Bringing talent and opportunity together – where the perfect match begins.
            </h1>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
