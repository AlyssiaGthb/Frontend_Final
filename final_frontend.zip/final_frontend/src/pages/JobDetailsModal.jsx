import React from "react";
import "./JobDetailsModal.css";

const JobDetailsModal = ({ job, onClose }) => {
  if (!job) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="close-button" onClick={onClose}>
          X
        </button>
        <h2>{job.title}</h2>
        <p><strong>Description :</strong> {job.description}</p>
        <p><strong>Skills :</strong> {job.skills}</p>
        <p><strong>Experience :</strong> {job.experience}</p>
        <p><strong>Location :</strong> {job.location}</p>
        <p><strong>Salary :</strong> {job.salary || "N/A"}</p>
        <p><strong>Languages :</strong> {job.languages || "N/A"}</p>
      </div>
    </div>
  );
};

export default JobDetailsModal;
