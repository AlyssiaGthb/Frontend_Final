import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./RecruiterDashboard.css";

const RecruiterDashboard = () => {
    const navigate = useNavigate();
    const [jobOffers, setJobOffers] = useState([]); // Liste des offres créées
    const [matchResults, setMatchResults] = useState({}); // Résultats de correspondance pour chaque offre
    const [showForm, setShowForm] = useState(false); // Afficher le formulaire
    const [formData, setFormData] = useState({
        title: "",
        description: "",
        skills: "",
        experience: "",
        education: "",
        languages: "",
        contract_type: "",
        salary: "",
        location: "",
    }); 

    const [selectedJob, setSelectedJob] = useState(null); // Offre sélectionnée pour prévisualisation
    const [error, setError] = useState(""); // Gestion des erreurs
    const [isLoading, setIsLoading] = useState(false); // État de chargement

    const token = localStorage.getItem("access_token"); // Récupérer le token JWT

    // Vérifier que l'utilisateur est un recruteur
    useEffect(() => {
        const userRole = localStorage.getItem("user_role");
        if (userRole !== "recruiter") {
            navigate("/"); 
        }
    }, [navigate]);

    // Charger les offres d'emploi créées
    useEffect(() => {
        const fetchJobOffers = async () => {
            try {
                const response = await axios.get("http://127.0.0.1:8002/filtered-jobs", {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                });
                setJobOffers(response.data); // Mettre à jour avec les offres récupérées
            } catch (err) {
                console.error("Erreur lors du chargement des offres :", err);
                setError("Failed to load job offers. Please try again.");
            }
        };

        fetchJobOffers();
    }, [token]);

    // Gestion du formulaire de création
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setIsLoading(true);

        try {
            const response = await axios.post(
                "http://127.0.0.1:8002/job/create",
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            setJobOffers([...jobOffers, response.data]); // Ajouter l'offre créée
            setShowForm(false);
            setFormData({
                title: "",
                description: "",
                skills: "",
                experience: "",
                education: "",
                languages: "",
                contract_type: "",
                salary: "",
                location: "",
            });
        } catch (err) {
            console.error("Erreur lors de la création de l'offre :", err);
            setError("Failed to create job offer. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    // Prévisualisation d'une offre
    const handlePreview = async (jobId) => {
        try {
            const response = await axios.get(
                `http://127.0.0.1:8002/job/preview?job_id=${jobId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            setSelectedJob(response.data);
        } catch (err) {
            console.error("Erreur lors de la prévisualisation :", err);
            setError("Failed to preview job offer. Please try again.");
        }
    };

    // Trouver les correspondances pour une offre
    const handleFindMatch = async (jobId) => {
        try {
            const response = await axios.post(
                `http://127.0.0.1:8003/job-to-cv?job_id=${jobId}`,
                {},
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );
            setMatchResults((prevResults) => ({
                ...prevResults,
                [jobId]: response.data.results,
            }));
        } catch (err) {
            console.error("Erreur lors de la recherche des correspondances :", err);
            setError("Failed to find matches. Please try again.");
        }
    };

    return (
        <div className="recruiter-dashboard">
            <h1>Recruiter Dashboard</h1>
            {error && <p className="error">{error}</p>}

            
            <button onClick={() => setShowForm(!showForm)} className="btn-primary">
                {showForm ? "Cancel" : "Create a Job Offer"}
            </button>

            
            {showForm && (
                <form onSubmit={handleSubmit} className="job-form">
                    <input
                        type="text"
                        name="title"
                        placeholder="Job Title"
                        value={formData.title}
                        onChange={handleInputChange}
                        required
                    />
                    <textarea
                        name="description"
                        placeholder="Job Description"
                        value={formData.description}
                        onChange={handleInputChange}
                        required
                    />
                    <textarea
                        name="skills"
                        placeholder="Required Skills"
                        value={formData.skills}
                        onChange={handleInputChange}
                        required
                    />
                    <input
                        type="text"
                        name="experience"
                        placeholder="Experience"
                        value={formData.experience}
                        onChange={handleInputChange}
                        required
                    />
                    <input
                        type="text"
                        name="education"
                        placeholder="Education"
                        value={formData.education}
                        onChange={handleInputChange}
                        required
                    />
                    <input
                        type="text"
                        name="languages"
                        placeholder="Languages"
                        value={formData.languages}
                        onChange={handleInputChange}
                    />
                    <input
                        type="text"
                        name="contract_type"
                        placeholder="Contract Type"
                        value={formData.contract_type}
                        onChange={handleInputChange}
                        required
                    />
                    <input
                        type="number"
                        name="salary"
                        placeholder="Salary"
                        value={formData.salary}
                        onChange={handleInputChange}
                    />
                    <input
                        type="text"
                        name="location"
                        placeholder="Location"
                        value={formData.location}
                        onChange={handleInputChange}
                    />
                    <button type="submit" className="btn-submit" disabled={isLoading}>
                        {isLoading ? "Submitting..." : "Submit"}
                    </button>
                </form>
            )}

           
            <h2>Your Job Offers</h2>
            {jobOffers.length === 0 ? (
                <p>No job offers yet. Create one to get started!</p>
            ) : (
                <ul className="job-offer-list">
                    {jobOffers.map((job) => (
                        <li key={job.id} className="job-offer-item">
                            <h3>{job.title}</h3>
                            <button
                                onClick={() => handlePreview(job.id)}
                                className="btn-preview"
                            >
                                Preview
                            </button>
                            <button
                                onClick={() => handleFindMatch(job.id)}
                                className="btn-match"
                            >
                                Find a Match
                            </button>
                            {matchResults[job.id] && (
                                <div className="match-results">
                                    <h4>Matches for {job.title}</h4>
                                    <ul>
                                        {matchResults[job.id].map((match) => (
                                            <li key={match.cv_id}>
                                                CV ID: {match.cv_id}, Similarity:{" "}
                                                {match.similarity_score.toFixed(2)}
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </li>
                    ))}
                </ul>
            )}

         
            {selectedJob && (
                <div className="modal">
                    <div className="modal-content">
                        <h2>{selectedJob.title}</h2>
                        <p>{selectedJob.description}</p>
                        <p>
                            <strong>Skills:</strong> {selectedJob.skills}
                        </p>
                        <p>
                            <strong>Experience:</strong> {selectedJob.experience}
                        </p>
                        <p>
                            <strong>Education:</strong> {selectedJob.education}
                        </p>
                        <p>
                            <strong>Languages:</strong> {selectedJob.languages}
                        </p>
                        <p>
                            <strong>Contract Type:</strong> {selectedJob.contract_type}
                        </p>
                        <p>
                            <strong>Salary:</strong> {selectedJob.salary}
                        </p>
                        <p>
                            <strong>Location:</strong> {selectedJob.location}
                        </p>
                        <button
                            onClick={() => setSelectedJob(null)}
                            className="btn-close"
                        >
                            Close
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default RecruiterDashboard;
