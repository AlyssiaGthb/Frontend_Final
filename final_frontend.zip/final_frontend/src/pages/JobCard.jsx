import React from "react";
import "./JobCard.css";

const JobCard = ({ job, onClick }) => {
  return (
    <div className="job-card" onClick={onClick}>
      <h3>{job.title}</h3>
      <p>{job.location}</p>
      <p>{job.contract_type}</p>
    </div>
  );
};

export default JobCard;
