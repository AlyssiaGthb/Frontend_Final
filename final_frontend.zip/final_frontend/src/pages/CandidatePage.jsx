import React, { useState, useEffect } from "react";
import axios from "axios";
import JobCard from "./JobCard";
import JobDetailsModal from "./JobDetailsModal";
import "./CandidateDashboard.css";

const CandidateDashboard = () => {
  const [jobs, setJobs] = useState([]); // Liste des offres
  const [selectedJob, setSelectedJob] = useState(null); // Job sélectionné
  const [showModal, setShowModal] = useState(false);

  // État pour la gestion du CV
  const [hasCv, setHasCv] = useState(false); // Vérifie si un CV est déjà uploadé
  const [showUploadModal, setShowUploadModal] = useState(false); // Contrôle l'affichage du modal d'upload
  const [file, setFile] = useState(null); // Fichier sélectionné
  const [cvPath, setCvPath] = useState(""); // Chemin du CV
  const [error, setError] = useState(""); // Gestion des erreurs

  // Récupérer les offres depuis l'API
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8002/jobs", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`, // Inclut le token
          },
        });
        setJobs(response.data);
      } catch (error) {
        console.error("Erreur lors du chargement des offres :", error);
      }
    };

    const checkCvStatus = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8001/cv/preview", {
          headers: { Authorization: `Bearer ${localStorage.getItem("access_token")}` },
        });
        setHasCv(true);
        setCvPath(response.data.file_path); // Stocke le chemin du CV
      } catch (err) {
        setHasCv(false);
      }
    };

    fetchJobs();
    checkCvStatus();
  }, []);

  // Afficher les détails dans un modal
  const openModal = (job) => {
    setSelectedJob(job);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedJob(null);
  };

  // Gère le changement de fichier
  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setError(""); // Réinitialise les erreurs
  };

  // Upload du CV
  const handleUpload = async () => {
    if (!file) {
      setError("Please select a file to upload.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await axios.post("http://127.0.0.1:8001/cv/upload", formData, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("access_token")}`,
          "Content-Type": "multipart/form-data",
        },
      });
      setHasCv(true);
      setCvPath(response.data.file_path); // Met à jour le chemin du CV
      setShowUploadModal(false); // Ferme le modal après succès
      setError(""); // Réinitialise les erreurs
    } catch (err) {
      console.error("Erreur lors de l'upload :", err);
      setError("Failed to upload the CV. Please try again.");
    }
  };

  return (
    <div className="candidate-dashboard">
      <div className="buttons">
        {!hasCv ? (
          <button className="btn-primary" onClick={() => setShowUploadModal(true)}>
            Upload CV
          </button>
        ) : (
          <button className="btn-secondary" onClick={() => window.open(cvPath, "_blank")}>
            Preview CV
          </button>
        )}
        <button className="btn-secondary">Find a Match</button>
      </div>

      <div className="job-list">
        {jobs.map((job) => (
          <JobCard key={job.id} job={job} onClick={() => openModal(job)} />
        ))}
      </div>

      {showModal && (
        <JobDetailsModal job={selectedJob} onClose={closeModal} />
      )}

      {/* Modal pour uploader un CV */}
      {showUploadModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Upload Your CV</h2>
            {error && <p className="error">{error}</p>}
            <input type="file" accept=".pdf,.doc,.docx" onChange={handleFileChange} />
            <div className="modal-actions">
              <button className="btn-primary" onClick={handleUpload}>
                Upload
              </button>
              <button className="btn-secondary" onClick={() => setShowUploadModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CandidateDashboard;
