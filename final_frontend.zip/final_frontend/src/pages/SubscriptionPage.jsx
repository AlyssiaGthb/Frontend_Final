import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SubscriptionPage.css';

const SubscriptionPage = () => {
    const [selectedPlan, setSelectedPlan] = useState(null);
    const [isProcessing, setIsProcessing] = useState(false); // State for payment animation
    const [confirmationMessage, setConfirmationMessage] = useState(''); // Confirmation message
    const navigate = useNavigate();

  
    const togglePlan = (plan) => {
        setSelectedPlan(selectedPlan === plan ? null : plan);
    };

   
    const handlePayment = (plan) => {
        setIsProcessing(true);
        setTimeout(() => {
            setIsProcessing(false);
            setConfirmationMessage(`Payment for ${plan} plan was successful!`);
            setTimeout(() => {
                navigate('/auth', { state: { showLogin: true } }); 
            }, 3000);
        }, 4000); 
    };

    
    const handleConfirm = (plan) => {
        if (plan === 'standard') {
            setConfirmationMessage('Subscribed to Standard plan!');
            setTimeout(() => {
                navigate('/auth', { state: { showLogin: true } }); 
            }, 3000);
        } else {
            handlePayment(plan); 
        }
    };

    return (
        <div className="subscription-page">
            {isProcessing && (
                <div className="payment-overlay">
                    <div className="payment-animation">
                        <div className="spinner"></div>
                        <p>Processing Payment...</p>
                    </div>
                </div>
            )}
            {confirmationMessage && (
                <div className="confirmation-overlay">
                    <div className="confirmation-message">
                        <h2>🎉 Success!</h2>
                        <p>{confirmationMessage}</p>
                        <p>Redirecting to the login page...</p>
                    </div>
                </div>
            )}
            <div className="subscription-frame">
                <h1>Choose your plan</h1>
                <div className="cards-container">
                
                    <div
                        className={`card ${selectedPlan === 'standard' ? 'expanded' : ''}`}
                        onClick={() => togglePlan('standard')}
                    >
                        <h2>Standard</h2>
                        <p>Free</p>
                        {selectedPlan === 'standard' && (
                            <div className="features">
                                <ul>
                                    <li>Upload a CV or a job offer</li>
                                    <li>Find your match</li>
                                    <li>Many job opportunities</li>
                                    <li>Simplify your research</li>
                                </ul>
                                <button
                                    className="confirm-btn"
                                    onClick={() => handleConfirm('standard')}
                                >
                                    Confirm
                                </button>
                            </div>
                        )}
                    </div>

                    
                    <div
                        className={`card ${selectedPlan === 'premium' ? 'expanded' : ''}`}
                        onClick={() => togglePlan('premium')}
                    >
                        <h2>Premium</h2>
                        <p>$15.99/month</p>
                        {selectedPlan === 'premium' && (
                            <div className="features">
                                <ul>
                                    <li>All Standard features</li>
                                    <li>Sort candidates and job offers by relevance</li>
                                </ul>
                                <button
                                    className="confirm-btn"
                                    onClick={() => handleConfirm('premium')}
                                >
                                    Confirm
                                </button>
                            </div>
                        )}
                    </div>

                    
                    <div
                        className={`card ${selectedPlan === 'platine' ? 'expanded' : ''}`}
                        onClick={() => togglePlan('platine')}
                    >
                        <h2>Platinum</h2>
                        <p>$19.99/month</p>
                        {selectedPlan === 'platine' && (
                            <div className="features">
                                <ul>
                                    <li>All Premium features</li>
                                    <li>Generate cover letters for you</li>
                                    <li>Chatbot to facilitate understanding</li>
                                </ul>
                                <button
                                    className="confirm-btn"
                                    onClick={() => handleConfirm('platine')}
                                >
                                    Confirm
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SubscriptionPage;
