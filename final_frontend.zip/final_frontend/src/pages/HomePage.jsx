import React from 'react';
import './HomePage.css';

const HomePage = () => {
    return (
        <div className="home-page">
            {/* Navbar */}
            <nav className="navbar">
    <div className="logo">Vitæ</div>
    <ul className="nav-links">
        <li><a href="#home">Home</a></li>
        <li><a href="#about">About us</a></li>
        <li><a href="#portfolio">SignIn</a></li>
        <li><a href="#portfolio">LogIn</a></li>
    </ul>
    <div className="menu-icon">
        <span></span>
        <span></span>
        <span></span>
    </div>
</nav>

            {/* Contenu principal */}
            <div className="main-content">
                <div className="text-section">
                <h1>Connecting Talent with Opportunity</h1>
                <p>We Match | We Empower | We Inspire Careers.</p>
                    <button className="cta-button">Let's Start</button>
                </div>
            </div>

            {/* Footer */}
            <footer className="footer">
                <div className="social-icons">
                    <a href="#"><i className="fa fa-instagram"></i></a>
                    <a href="#"><i className="fa fa-twitter"></i></a>
                    <a href="#"><i className="fa fa-facebook"></i></a>
                </div>
            </footer>
        </div>
    );
};

export default HomePage;
