import React from "react";
import { Link, useNavigate } from "react-router-dom"; // Importer useNavigate
import "./Navbar.css";

const Navbar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    console.log("Avant suppression :", localStorage.getItem("access_token"), localStorage.getItem("user_role"));
    localStorage.removeItem("access_token");
    localStorage.removeItem("user_role");
    console.log("Après suppression :", localStorage.getItem("access_token"), localStorage.getItem("user_role"));

    // Rediriger vers la page de connexion
    navigate("/auth");
  };

  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <Link to="/">Vitae</Link>
      </div>
      <ul className="navbar-links">
        <li>
          <button className="logout-btn" onClick={handleLogout}>
            Logout
          </button>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
