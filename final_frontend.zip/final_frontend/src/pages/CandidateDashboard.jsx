import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import JobCard from "./JobCard";
import JobDetailsModal from "./JobDetailsModal";
import "./CandidateDashboard.css";

const CandidateDashboard = () => {
  const [jobs, setJobs] = useState([]); // Liste des offres
  const [matchedJobs, setMatchedJobs] = useState([]); // Jobs correspondants
  const [selectedJob, setSelectedJob] = useState(null); // Job sélectionné
  const [showModal, setShowModal] = useState(false);
  const [file, setFile] = useState(null); // Fichier CV
  const [cvUploaded, setCvUploaded] = useState(false); // État pour vérifier si le CV a été uploadé
  const [error, setError] = useState(""); // Gestion des erreurs
  const [loading, setLoading] = useState(false); // État de chargement
  const [showLetterModal, setShowLetterModal] = useState(false); // Modal de la lettre
  const [generatedLetter, setGeneratedLetter] = useState(""); // Contenu de la lettre générée

  const cvFileRef = useRef(null); // Référence au fichier CV

  // Récupérer les offres depuis le backend
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8002/jobs", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`,
          },
        });
        setJobs(response.data);
      } catch (error) {
        console.error("Erreur lors du chargement des offres :", error);
        setError("Failed to fetch job listings. Please try again later.");
      }
    };

    fetchJobs();
  }, []);

  // Gère le changement de fichier pour le CV
  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
    cvFileRef.current = selectedFile; 
    setCvUploaded(false);
    setError("");
  };

  // Fonction pour uploader le CV
  const handleUploadCv = async () => {
    if (!file) {
      setError("Please select a file to upload.");
      return;
    }

    setLoading(true); 
    setError("");

    try {
      const formData = new FormData();
      formData.append("file", file);

      const uploadResponse = await axios.post(
        "http://127.0.0.1:8003/cv-to-job", 
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      // Récupération des résultats de matching
      setMatchedJobs(uploadResponse.data.results);
      setCvUploaded(true); 
      console.log("Matching réussi :", uploadResponse.data.results);
    } catch (err) {
      console.error("Erreur lors de l'upload et matching :", err);
      setError("Failed to upload and match the CV. Please try again.");
    } finally {
      setLoading(false); 
    }
  };

  // Fonction pour faire le matching séparé (si nécessaire)
  const handleFindMatch = async () => {
    if (!cvUploaded) {
      setError("Please upload your CV before finding matches.");
      return;
    }

    setLoading(true); 
    setError("");

    try {
      const jobIds = jobs.map((job) => job.id); 
      const matchResponse = await axios.post(
        "http://127.0.0.1:8003/cv-to-job",
        {
          job_ids: jobIds,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`,
          },
        }
      );

      setMatchedJobs(matchResponse.data.results); 
      console.log("Jobs correspondants :", matchResponse.data.results);
    } catch (err) {
      console.error("Erreur lors du matching :", err);
      setError("Failed to find matches. Please try again.");
    } finally {
      setLoading(false); 
    }
  };

  // Afficher les détails dans un modal
  const openModal = (job) => {
    setSelectedJob(job);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedJob(null);
  };

  // Gestion du bouton "Apply"
  const handleApply = (job) => {
    alert(`Applied successfully for ${job.title}`);
  };

  // Gestion du bouton "Apply with Letter"
  const handleApplyWithLetter = async (job) => {
    if (!cvUploaded || !cvFileRef.current) {
      setError("Please upload your CV before applying with a letter.");
      return;
    }

    try {
      const formData = new FormData();
      formData.append("file", cvFileRef.current); // CV
      formData.append("job_id", job.id); // ID du job

      const response = await axios.post(
        "http://127.0.0.1:8004/letter/generate",
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`,
            "Content-Type": "multipart/form-data",
          },
        }
      );

      setGeneratedLetter(response.data.letter_content);
      setSelectedJob(job);
      setShowLetterModal(true);
    } catch (err) {
      console.error("Erreur lors de la génération de la lettre :", err);
      setError("Failed to generate letter. Please try again.");
    }
  };

  // Fonction pour enregistrer la lettre
  const handleSaveLetter = async () => {
    try {
      await axios.post(
        "http://127.0.0.1:8004/letter/save",
        {
          job_id: selectedJob.id,
          letter_content: generatedLetter,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`,
          },
        }
      );
      alert("Letter saved successfully!");
      setShowLetterModal(false);
    } catch (err) {
      console.error("Erreur lors de l'enregistrement de la lettre :", err);
      setError("Failed to save the letter. Please try again.");
    }
  };

  return (
    <div className="candidate-dashboard">
      <div className="buttons">
        <input
          type="file"
          accept=".pdf"
          onChange={handleFileChange}
          style={{ marginRight: "10px" }}
        />
        <button
          className="btn-primary"
          onClick={handleUploadCv}
          disabled={loading || cvUploaded}
        >
          {loading ? "Uploading..." : cvUploaded ? "Uploaded" : "Upload CV"}
        </button>
        <button
          className="btn-secondary"
          onClick={handleFindMatch}
          disabled={loading || !cvUploaded}
        >
          {loading ? "Matching..." : "Find a Match"}
        </button>
      </div>

      <div className="job-list">
        <h2>All Jobs</h2>
        {jobs.length === 0 ? (
          <p>No jobs available at the moment.</p>
        ) : (
          jobs.map((job) => (
            <JobCard key={job.id} job={job} onClick={() => openModal(job)} />
          ))
        )}
      </div>

      <div className="matched-jobs">
        <h2>Matched Jobs</h2>
        {matchedJobs.length === 0 ? (
          <p>No matched jobs yet. Upload your CV to find matches.</p>
        ) : (
          matchedJobs.map((match) => {
            const matchedJob = jobs.find((job) => job.id === match.job_id);
            const stars = Array.from(
              { length: 5 },
              (_, i) =>
                i < Math.round(match.similarity_score * 5) ? "★" : "☆"
            ).join("");

            return (
              matchedJob && (
                <div key={match.id} className="matched-job-card">
                  <h3>{matchedJob.title}</h3>
                  <p>{matchedJob.location}</p>
                  <p>{matchedJob.contract_type}</p>
                  <p>{stars}</p>
                  <button
                    className="btn-details"
                    onClick={() => openModal(matchedJob)}
                  >
                    View Details
                  </button>
                  <button
                    className="btn-apply"
                    onClick={() => handleApply(matchedJob)}
                  >
                    Apply
                  </button>
                  <button
                    className="btn-apply-letter"
                    onClick={() => handleApplyWithLetter(matchedJob)}
                  >
                    Apply with Letter
                  </button>
                </div>
              )
            );
          })
        )}
      </div>

      {showModal && (
        <JobDetailsModal job={selectedJob} onClose={closeModal} />
      )}

      {showLetterModal && (
        <div className="modal">
          <div className="modal-content">
            <h2>Edit Generated Letter</h2>
            <textarea
              value={generatedLetter}
              onChange={(e) => setGeneratedLetter(e.target.value)}
              rows={10}
              cols={50}
            />
            <div className="modal-actions">
              <button onClick={() => setShowLetterModal(false)}>Close</button>
              <button onClick={handleSaveLetter}>Submit</button>
            </div>
          </div>
        </div>
      )}

      {error && <p className="error">{error}</p>}
    </div>
  );
};

export default CandidateDashboard;
